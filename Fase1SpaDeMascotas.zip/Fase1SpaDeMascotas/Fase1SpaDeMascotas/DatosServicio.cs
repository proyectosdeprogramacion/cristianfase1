﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fase1SpaDeMascotas
{
    public partial class DatosServicio : Form
    {
        public DatosServicio()
        {
            InitializeComponent();
        }

        private void DatosServicio_Load(object sender, EventArgs e)
        {
            //Carga los datos del usuario y el total a pagar
            Persona persona = new Persona();

            persona.TotalPagar();

            lblCliente.Text = "Cliente: " + Persona.nombre;
            lblMascota.Text = "Mascota: " + Persona.mascota;
            lblEstratoSocial.Text = "Estrato social: " + Persona.estratoSocial;
            lblTotalPagar.Text = "Total del servicio: " + Persona.totalPagar.ToString();
        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            this.Hide();
            Formulario frml = new Formulario();
            frml.Show();
        }
    }
}
