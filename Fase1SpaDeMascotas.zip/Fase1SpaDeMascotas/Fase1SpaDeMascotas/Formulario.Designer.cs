﻿namespace Fase1SpaDeMascotas
{
    partial class Formulario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnOrdenar = new System.Windows.Forms.Button();
            this.rb100000 = new System.Windows.Forms.RadioButton();
            this.rb80000 = new System.Windows.Forms.RadioButton();
            this.rb45000 = new System.Windows.Forms.RadioButton();
            this.cmbEstratoSocial = new System.Windows.Forms.ComboBox();
            this.txtMascota = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtCLiente = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.btnOrdenar);
            this.panel1.Controls.Add(this.rb100000);
            this.panel1.Controls.Add(this.rb80000);
            this.panel1.Controls.Add(this.rb45000);
            this.panel1.Controls.Add(this.cmbEstratoSocial);
            this.panel1.Controls.Add(this.txtMascota);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.txtCLiente);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(64, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(674, 479);
            this.panel1.TabIndex = 0;
            // 
            // btnOrdenar
            // 
            this.btnOrdenar.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnOrdenar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(85)))), ((int)(((byte)(255)))));
            this.btnOrdenar.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(85)))), ((int)(((byte)(255)))));
            this.btnOrdenar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOrdenar.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnOrdenar.ForeColor = System.Drawing.Color.White;
            this.btnOrdenar.Location = new System.Drawing.Point(453, 404);
            this.btnOrdenar.Name = "btnOrdenar";
            this.btnOrdenar.Size = new System.Drawing.Size(200, 60);
            this.btnOrdenar.TabIndex = 14;
            this.btnOrdenar.Text = "Ordenar Servicio";
            this.btnOrdenar.UseVisualStyleBackColor = false;
            this.btnOrdenar.Click += new System.EventHandler(this.btnOrdenar_Click);
            // 
            // rb100000
            // 
            this.rb100000.AutoSize = true;
            this.rb100000.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.rb100000.Location = new System.Drawing.Point(203, 334);
            this.rb100000.Name = "rb100000";
            this.rb100000.Size = new System.Drawing.Size(450, 25);
            this.rb100000.TabIndex = 13;
            this.rb100000.TabStop = true;
            this.rb100000.Text = "Baño, corte, Vacunas antigarrapatas y Antiparásitos $100.000";
            this.rb100000.UseVisualStyleBackColor = true;
            this.rb100000.CheckedChanged += new System.EventHandler(this.rb100000_CheckedChanged);
            // 
            // rb80000
            // 
            this.rb80000.AutoSize = true;
            this.rb80000.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.rb80000.Location = new System.Drawing.Point(203, 303);
            this.rb80000.Name = "rb80000";
            this.rb80000.Size = new System.Drawing.Size(338, 25);
            this.rb80000.TabIndex = 12;
            this.rb80000.TabStop = true;
            this.rb80000.Text = "Baño, corte y vacuna antigarrapatas, $80.000";
            this.rb80000.UseVisualStyleBackColor = true;
            this.rb80000.CheckedChanged += new System.EventHandler(this.rb80000_CheckedChanged);
            // 
            // rb45000
            // 
            this.rb45000.AutoSize = true;
            this.rb45000.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.rb45000.Location = new System.Drawing.Point(203, 272);
            this.rb45000.Name = "rb45000";
            this.rb45000.Size = new System.Drawing.Size(178, 25);
            this.rb45000.TabIndex = 11;
            this.rb45000.TabStop = true;
            this.rb45000.Text = "Baño y corte, $45.000";
            this.rb45000.UseVisualStyleBackColor = true;
            this.rb45000.CheckedChanged += new System.EventHandler(this.rb45000_CheckedChanged);
            // 
            // cmbEstratoSocial
            // 
            this.cmbEstratoSocial.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cmbEstratoSocial.FormattingEnabled = true;
            this.cmbEstratoSocial.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "Mayor a 5"});
            this.cmbEstratoSocial.Location = new System.Drawing.Point(203, 214);
            this.cmbEstratoSocial.Name = "cmbEstratoSocial";
            this.cmbEstratoSocial.Size = new System.Drawing.Size(373, 29);
            this.cmbEstratoSocial.TabIndex = 10;
            // 
            // txtMascota
            // 
            this.txtMascota.BackColor = System.Drawing.Color.White;
            this.txtMascota.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtMascota.Location = new System.Drawing.Point(203, 169);
            this.txtMascota.Name = "txtMascota";
            this.txtMascota.Size = new System.Drawing.Size(373, 29);
            this.txtMascota.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(77, 272);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 21);
            this.label5.TabIndex = 8;
            this.label5.Text = "Servicio";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(74, 172);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 21);
            this.label3.TabIndex = 7;
            this.label3.Text = "Mascota";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(74, 217);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 21);
            this.label2.TabIndex = 6;
            this.label2.Text = "Estrato social";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(74, 115);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 21);
            this.label4.TabIndex = 5;
            this.label4.Text = "Cliente";
            // 
            // txtCLiente
            // 
            this.txtCLiente.BackColor = System.Drawing.Color.White;
            this.txtCLiente.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtCLiente.Location = new System.Drawing.Point(203, 112);
            this.txtCLiente.Name = "txtCLiente";
            this.txtCLiente.Size = new System.Drawing.Size(373, 29);
            this.txtCLiente.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Black;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(182, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(314, 45);
            this.label1.TabIndex = 2;
            this.label1.Text = "Formulario Servicio";
            // 
            // Formulario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(800, 503);
            this.Controls.Add(this.panel1);
            this.Name = "Formulario";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Formulario";
            this.Load += new System.EventHandler(this.Formulario_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Panel panel1;
        private TextBox txtCLiente;
        private Label label1;
        private Label label5;
        private Label label3;
        private Label label2;
        private Label label4;
        private TextBox txtMascota;
        private ComboBox cmbEstratoSocial;
        private RadioButton rb100000;
        private RadioButton rb80000;
        private RadioButton rb45000;
        private Button btnOrdenar;
    }
}