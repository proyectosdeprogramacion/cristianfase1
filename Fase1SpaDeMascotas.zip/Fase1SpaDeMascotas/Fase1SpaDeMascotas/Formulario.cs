﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fase1SpaDeMascotas
{
    public partial class Formulario : Form
    {
        int servicio;
        int descuento;
        bool guardar = false;

        public Formulario()
        {
            InitializeComponent();
        }

        private void btnOrdenar_Click(object sender, EventArgs e)
        {
            if (txtMascota.Text != null || txtCLiente.Text != null || cmbEstratoSocial.Text != null)
            {
                if (guardar == true)
                {
                    GuardarDatos();

                    this.Hide();
                    DatosServicio datos = new DatosServicio();
                    datos.Show();
                }
                else
                {
                    MessageBox.Show("Seleccione un servicio");
                }
            }
            else
            {
                MessageBox.Show("Diligenci todas las casillas para continuar");
            }
        }

        private void GuardarDatos()
        {
            //Datos Coto del servicio
            if (rb45000.Checked == true)
            {
                servicio = 45000;
            }
            else if (rb80000.Checked == true)
            {
                servicio = 80000;
            }
            else if (rb100000.Checked == true)
            {
                servicio = 100000;
            }    


            //Datos Descuento
            if (cmbEstratoSocial.Text == "1" || cmbEstratoSocial.Text == "2")
            {
                descuento = 15; 
            }
            else if (cmbEstratoSocial.Text == "3" || cmbEstratoSocial.Text == "4")
            {
                descuento = 10;
            }
            else if (cmbEstratoSocial.Text == "5" || cmbEstratoSocial.Text == "Mayor a 5")
            {
                descuento = 5;
            }

            //Envia datos a la clase
            Persona.nombre = txtCLiente.Text;
            Persona.mascota = txtMascota.Text;
            Persona.estratoSocial = cmbEstratoSocial.Text;
            Persona.valorServicio = servicio;
            Persona.descuento = descuento;
        }

        private void rb45000_CheckedChanged(object sender, EventArgs e)
        {
            guardar = true;
        }

        private void rb80000_CheckedChanged(object sender, EventArgs e)
        {
            guardar = true;
        }

        private void rb100000_CheckedChanged(object sender, EventArgs e)
        {
            guardar = true;
        }

        private void Formulario_Load(object sender, EventArgs e)
        {
            txtMascota.Focus();
        }
    }
}
