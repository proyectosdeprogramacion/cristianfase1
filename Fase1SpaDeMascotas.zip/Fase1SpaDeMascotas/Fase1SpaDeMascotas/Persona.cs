﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fase1SpaDeMascotas
{
    internal class Persona
    {
        public static string nombre;
        public static string mascota;
        public static string estratoSocial;
        public static int valorServicio;
        public static int descuento;
        public static int totalPagar;

        public void TotalPagar()
        {
            totalPagar = valorServicio - (valorServicio * descuento / 100);
        }
    }
}
