﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fase1SpaDeMascotas
{
    public partial class Sesion : Form
    {
        public Sesion()
        {
            InitializeComponent();
        }

        private void Sesion_Load(object sender, EventArgs e)
        {
            txtClave.Focus();
        }

        private void btnIniciarSesion_Click(object sender, EventArgs e)
        {
            //Condición para la clave de acceso al sistema
            switch (txtClave.Text)
            {
                case "123":
                  
                    this.Hide();
                    Formulario frml = new Formulario();
                    frml.Show();

                    break;
                default:

                    MessageBox.Show("Clave incorrecta, intente nuevamente");

                    break;
            }
        }
    }
}
